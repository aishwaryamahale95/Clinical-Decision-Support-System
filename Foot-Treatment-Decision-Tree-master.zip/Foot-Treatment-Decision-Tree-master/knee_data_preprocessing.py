# -*- coding: utf-8 -*-
"""
Created on Tue Jun  7 18:23:46 2022

@author: yzhu9
"""

import pandas as pd

csv_file = 'qry_KneeTreatmentDecisionTree.csv'
critical_columns = ['Code','RRN', 'EncountersAge', 'MotionParams.Side', 
                    'AnkleDorsiPlantarMeanStanceDF', 'KneeFlexionAtIC',
                    'KneeFlexionMin', 'HipFlexionMin']

left_side_columns = ['LeftKneeRomPopAngle', 'LeftForefootWtBearing', 
                     'LeftMidfootWtBearing', 'LeftHindfootWtBearing']
right_side_columns = ['RightKneeRomPopAngle', 'RightForefootWtBearing', 
                     'RightMidfootWtBearing', 'RightHindfootWtBearing']

df = pd.read_csv(csv_file)
print(df.shape)

# for column in right_side_columns:
#     if column not in df.keys():
#         print(column)

df.dropna(subset=critical_columns, inplace=True)

print(df.head())
print(df.shape)

df_left = df[df['MotionParams.Side']=='Left'].dropna(subset=left_side_columns)

print(df_left.shape)

df_right = df[df['MotionParams.Side']=='Right'].dropna(subset=right_side_columns)

print(df_right.shape)

df_res = pd.concat([df_left, df_right], ignore_index=True)

print(df_res.shape)

df_res = df_res.drop_duplicates()

print(df_res.shape)

df_res.to_csv('cleaned_qry_KneeTreatmentDecisionTree.csv')